package com.example.GRP_Spring_Proj;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GrpSpringProjApplicationTests {

	@Test
	void contextLoads() {
	}

}
