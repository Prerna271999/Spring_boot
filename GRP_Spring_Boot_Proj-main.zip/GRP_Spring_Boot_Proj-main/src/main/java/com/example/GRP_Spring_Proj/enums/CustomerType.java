package com.example.GRP_Spring_Proj.enums;

public enum CustomerType {
    GOLD,SILVER,PLATINUM;
}

